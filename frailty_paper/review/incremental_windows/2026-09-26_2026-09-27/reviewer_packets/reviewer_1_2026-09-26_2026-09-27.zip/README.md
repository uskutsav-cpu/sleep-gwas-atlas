# Supplemental PubMed title/abstract screening

This packet contains seven unique records retrieved for publication dates 2026-09-26 through 2026-09-27. It is a supplemental queue and is not merged into the frozen 56,117-record canonical queue.

Two people must screen independently. Each reviewer should receive only their own ZIP and must not compare decisions before both returns are collected. Read the included frozen `protocol.md` before screening. In the single TSV batch, preserve `screening_id` and every source-information column; fill only `decision`, `reason`, `reviewer`, and optional `notes`. Use `include`, `exclude`, or `unclear` for `decision`; identify yourself consistently in `reviewer`. Do not make full-text decisions in this file.

Return the completed TSV without renaming it, together with this README and `protocol.md`. Keep a copy of the original blank archive. The project team will validate both returned reviewer packets before applying decisions to this supplemental queue. Do not merge these records into the canonical queue automatically.
